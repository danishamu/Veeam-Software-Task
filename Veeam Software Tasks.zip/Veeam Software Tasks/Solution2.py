from dirsync import sync

sync('C:\\Users\Danish Iqbal\Documents\source', 'C:\\Users\Danish Iqbal\Documents\Replica', 'sync', purge = True)